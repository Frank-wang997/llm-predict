#!/bin/bash
nohup jupyter notebook --allow-root > jupyter.log 2>&1 &
